package com.example.taptosleep

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()
